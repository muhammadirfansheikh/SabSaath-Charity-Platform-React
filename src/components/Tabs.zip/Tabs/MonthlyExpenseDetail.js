import React, { useState, Link } from 'react'
import { useHistory } from "react-router-dom";
import {
  Card,
  CardHeader,
  CardBody,
  CardTitle,
  Table,
  Row,
  Col,
  Button,
  FormGroup,
  Form,
  Label,
  Option,
  Input,
  check,
  Badge
} from "reactstrap";

const MonthlyExpenseDetail = (props) => {

const AddMonthlyExpenseInGrid=(e)=>{
  e.preventDefault();
  debugger;
  var alreadyexists=false;
  var MonthlyExpenseGridData=props.monthlyExpenseValues.ExpenseGridList===undefined?[]:props.monthlyExpenseValues.ExpenseGridList;
      if(props.monthlyExpenseValues.ExpenseId==='0' || props.monthlyExpenseValues.ExpenseValue<=0)
      {
        alert("Must fill the fields");
      }
      else
      {
        if(MonthlyExpenseGridData.length>0)
        {
            alreadyexists=MonthlyExpenseGridData.some(el => el.ExpenseId === props.monthlyExpenseValues.ExpenseId);
            alreadyexists && alert("Already Exists");
        }
        if(!alreadyexists)
        {
            MonthlyExpenseGridData.push({ExpenseId:props.monthlyExpenseValues.ExpenseId
            ,ExpenseName:GetSetupDetail_Name(props.monthlyExpenseValues.ExpenseId,props.monthlyExpenseValues.ExpenseDdl)
              ,ExpenseValue:props.monthlyExpenseValues.ExpenseValue});

            console.log("MonthlyExpenseGridData",MonthlyExpenseGridData);
            props.handleExpenseGridChange(MonthlyExpenseGridData);
        }
      }
};
  function GetSetupDetail_Name(SetupDetailId,SetupDetailList) {
  var filterdata="";
  if(SetupDetailId>0 && SetupDetailId!=undefined && SetupDetailId!=null)
  {
   filterdata= SetupDetailList.filter(p => p.SetupDetailId ===parseInt(SetupDetailId))[0].SetupDetailName;
  console.log("filterdata",filterdata);
  return filterdata;
  }
  
  return filterdata;
}

 function GetTotalExpense() {
  var TotalExpense=0;
  console.log("monthlyexpense");
  props.monthlyExpenseValues.ExpenseGridList &&
  props.monthlyExpenseValues.ExpenseGridList.map((item,key)=>{
      TotalExpense+=parseInt(item.ExpenseValue);
  })
  
  return TotalExpense;
}

const onDelete = ({ ExpenseId }) => {
    console.log(ExpenseId);
    var listexpense=props.monthlyExpenseValues.ExpenseGridList;
    const indx = listexpense.findIndex(v => v.ExpenseId === ExpenseId);
listexpense.splice(indx, indx >= 0 ? 1 : 0);
props.handleExpenseGridChange(listexpense);
  }
return(
<div>  
<Card className="mb-3">
  <CardHeader>
  <h6 className="font-weight-bold mb-0">Monthly Expense</h6>
  </CardHeader>
  <CardBody>
    <Form>
      <Row form>
      <Col md={3}>
          <FormGroup>
            <Label for="">Expense</Label>
            <Input type="select" className="form-control" name="ExpenseId" value={props.monthlyExpenseValues.ExpenseId} onChange={props.handleMonthlyExpenseInputChange}>
            <option key={0} value={0} >Select</option>
            {
              props.monthlyExpenseValues.ExpenseDdl &&
                            props.monthlyExpenseValues.ExpenseDdl.map((item, key) => (
                              <option key={item.SetupDetailId} value={item.SetupDetailId}>
                                {item.SetupDetailName}
                              </option>
                            ))
                          }  
          </Input>
          </FormGroup>
        </Col>
        <Col md={3}>
          <FormGroup>
            <Label for="">Amount</Label>
            <Input type="text" className="form-control" name="ExpenseValue" value={props.monthlyExpenseValues.ExpenseValue} onChange={props.handleMonthlyExpenseInputChange} />
          </FormGroup>
        </Col>
      </Row>
      <Row className="text-right">
        <Col md={12}>
          <FormGroup>
            <Button color="primary" onClick={AddMonthlyExpenseInGrid}>Add</Button>
          </FormGroup>
        </Col>
      </Row>
    </Form>
    <Row>
<Col md={12}>
  <h2 className="h6">Expense Detail</h2>
</Col>
</Row>
<Row>
<Col md={12}>
  <table className="table">
    <thead>
      <tr>
        <th>Expense</th>
        <th>Amount</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
    {
            props.monthlyExpenseValues.ExpenseGridList &&
                            props.monthlyExpenseValues.ExpenseGridList.map((item, key) => (
                              <tr key={key}>
                             <td>{item.ExpenseName}</td>
                              <td>{item.ExpenseValue}</td>
                               <td>
                          <Button color="danger" outline size="sm" onClick={() => onDelete({ ExpenseId: item.ExpenseId })}><i className="nc-icon nc-simple-remove"></i></Button>
                        </td>
                              </tr>
                            ))
    }  
     
     
    </tbody>
    <tfoot>
<tr>
<td  colSpan="3" style={{fontWeight: 'bold'}} className='text-right'>Total: {GetTotalExpense()}</td>
</tr>
    </tfoot>
  </table>
</Col>
</Row>
  </CardBody>
</Card>

</div>
    );



}

export default MonthlyExpenseDetail