import React, { useState, Link } from 'react'
import { useHistory } from "react-router-dom";
import {
  Card,
  CardHeader,
  CardBody,
  CardTitle,
  Table,
  Row,
  Col,
  Button,
  FormGroup,
  Form,
  Label,
  Option,
  Input,
  check,
  Badge
} from "reactstrap";

const SourceOfDrinkingSanitationAndWashroom = (props) => {
  return (
    <div>
      <Card className="mb-3">
        <CardHeader>
          <h6 className="font-weight-bold mb-0">Source of Drinking/ Sanitation and Washroom </h6>
        </CardHeader>
        <CardBody>
          <Form>
            <Row form>
            <Col md={4}>
            <FormGroup>
              <Label for="InputState">What is the main source of drinking water?</Label>
              <Input type="select" className="form-control" name="SourceDrinkId" value={props.drinkSanitationValues.SourceDrinkId} onChange={props.handleDrinkingInputChange}>
            <option key={0} value={0} >Select</option>
            {
              props.drinkSanitationValues.SourceDrinkddl &&
                            props.drinkSanitationValues.SourceDrinkddl.map((item, key) => (
                              <option key={item.SetupDetailId} value={item.SetupDetailId}>
                                {item.SetupDetailName}
                              </option>
                            ))
                          }  
          </Input>
             </FormGroup>
            </Col>
            <Col md={4}>
            <FormGroup>
              <div className="form-check-inline mt-3 pt-3">
                <Label className="form-check-Label">
                <Input type="checkbox" className="form-check-Input"  checked={props.drinkSanitationValues.IsToiletPresent} onChange={props.handleDrinkingInputChange} />Does your house have a toilet?
                </Label>
              </div>
            </FormGroup>
          </Col>
            </Row>
          </Form>
        </CardBody>
      </Card>
      
      {/* <Row className="text-right">
        <Col md={12}>
          <FormGroup>
            <Button color="primary">Save</Button>
          </FormGroup>
        </Col>
      </Row> */}
    </div>
  );



}

export default SourceOfDrinkingSanitationAndWashroom