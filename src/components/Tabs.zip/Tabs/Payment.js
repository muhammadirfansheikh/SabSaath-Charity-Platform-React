import React, { useState, Link } from 'react'
import { useHistory } from "react-router-dom";
import {
  Card,
  CardHeader,
  CardBody,
  CardTitle,
  Table,
  Row,
  Col,
  Button,
  FormGroup,
  Form,
  Label,
  Option,
  Input,
  check,
  Badge
} from "reactstrap";

const Payment = (props) => {
  return (
    
    <div>
      <Card className="mb-3">
        <CardHeader>
          <h6 className="font-weight-bold mb-0">Payment</h6>
        </CardHeader>
        <CardBody>
          <Form>

             {/*amount*/}

            <Row form>
              <Col md={3}>
                <FormGroup>
                  <Label for="">Amount</Label>
                  <Input type="number" className="form-control" id="" />
                </FormGroup>
              </Col>
              <Col md={3}>
                <FormGroup>
                  <Label for="InputState">Payment Type</Label>
                  <select id="InputState" className="form-control">
                    <option >Cash</option>
                    <option >Check</option>
                    <option >Transfer</option>
                    <option >Jazz Cash</option>
                    <option >Easy Paisa</option>
                  </select>
                </FormGroup>
              </Col>
            </Row>

            {/*amount*/}

            
             {/*cash*/}

            <Row form>
            <Col md={12}>
              <h6>If Cash</h6>
            </Col>
            </Row>

          <Row form>
          <Col md={3}>
          <FormGroup check>
                <Input
                  name="checkbox1"
                  type="checkbox"
                />
                {' '}
                <Label check>
                Self
              </Label>
            </FormGroup>
          </Col>

            <Col md={3}>
            <FormGroup>
              <Label for="">Received by</Label>
              <Input type="text" className="form-control" id="" />
            </FormGroup>
          </Col>
            <Col md={3}>
            <FormGroup>
              <Label for="">CNIC</Label>
              <Input type="number" className="form-control" id="" />
            </FormGroup>
          </Col>
          </Row>
           {/*cash*/}
            
            {/*if cheque*/}

            <Row form>
            <Col md={12}>
             <h6>If Cheque</h6>
            </Col>
          </Row>

          <Row form>
          <Col md={3}>
          <FormGroup>
            <Label for="InputState">Bank</Label>
            <select id="InputState" className="form-control">
              <option >HBL</option>
            </select>
          </FormGroup>
        </Col>

        <Col md={3}>
        <FormGroup>
          <Label for="InputState">Branch</Label>
          <select id="InputState" className="form-control">
            <option >Saddar</option>
          </select>
        </FormGroup>
      </Col>
            <Col md={3}>
              <FormGroup>
                <Label for="">Cheque Number</Label>
                <Input type="number" className="form-control" id="" />
              </FormGroup>
            </Col>

            <Col md={3}>
              <FormGroup>
                <Label for="">Upload Cheque</Label>
                <Input type="file" className="form-control" id="" />
              </FormGroup>
            </Col>
            
          </Row>
               {/*if cheque*/}


            {/*if transfer*/}
            <Row form>
            <Col md={12}>
                  <h6>If Bank Transfer</h6>
            </Col>
          </Row>

          <Row form>
          <Col md={3}>
              <FormGroup>
                <Label for="InputState">Bank</Label>
                <select id="InputState" className="form-control">
                  <option >HBL</option>
                </select>
              </FormGroup>
            </Col>
            <Col md={3}>
              <FormGroup>
                <Label for="">Account Number</Label>
                <Input type="number" className="form-control" id="" />
              </FormGroup>
            </Col>
            
            <Col md={3}>
            <FormGroup>
              <Label for="">Account title</Label>
              <Input type="text" className="form-control" id="" />
            </FormGroup>
          </Col>

          <Col md={3}>
          <FormGroup>
            <Label for="">Upload Screenshot</Label>
            <Input type="file" className="form-control" id="" />
          </FormGroup>
        </Col>
          </Row>
             {/*if transfer*/}


              {/*if jazz cash*/}
            <Row form>
            <Col md={12}>
                  <h6>If Jazz Cash</h6>
            </Col>
          </Row>

          <Row form>
          
            <Col md={3}>
              <FormGroup>
                <Label for="">Mobile Number</Label>
                <Input type="number" className="form-control" id="" />
              </FormGroup>
            </Col>
            
            <Col md={3}>
            <FormGroup>
              <Label for="">Account Name</Label>
              <Input type="text" className="form-control" id="" />
            </FormGroup>
          </Col>

          <Col md={3}>
          <FormGroup>
            <Label for="">Upload Screenshot</Label>
            <Input type="file" className="form-control" id="" />
          </FormGroup>
        </Col>
          </Row>
             {/*if jazz cash*/}



               {/*if easy paisa*/}
            <Row form>
            <Col md={12}>
                  <h6>If Easy Paisa</h6>
            </Col>
          </Row>

          <Row form>
         
            <Col md={3}>
              <FormGroup>
                <Label for="">Mobile Number</Label>
                <Input type="number" className="form-control" id="" />
              </FormGroup>
            </Col>
            
            <Col md={3}>
            <FormGroup>
              <Label for="">Account Name</Label>
              <Input type="text" className="form-control" id="" />
            </FormGroup>
          </Col>

          <Col md={3}>
          <FormGroup>
            <Label for="">Upload Screenshot</Label>
            <Input type="file" className="form-control" id="" />
          </FormGroup>
        </Col>
          </Row>
           
               {/*if easy paisa*/}


          </Form>
        </CardBody>
      </Card>
     

    </div>
  );

}

export default Payment