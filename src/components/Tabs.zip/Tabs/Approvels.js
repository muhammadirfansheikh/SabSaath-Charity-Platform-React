import React, { useState, Link } from 'react'
import { useHistory } from "react-router-dom";
import {
  Card,
  CardHeader,
  CardBody,
  CardTitle,
  Table,
  Row,
  Col,
  Button,
  FormGroup,
  Form,
  Label,
  Option,
  Input,
  check,
  Badge
} from "reactstrap";

const Approvels = (props) => {
  return (
    <div>
      <Card className="mb-3">
        <CardHeader>
          <h6 className="font-weight-bold mb-0">Investigator Approval</h6>
        </CardHeader>
        <CardBody>
          <Form>
            <Row form>
              <Col md={12}>
              <FormGroup check>
                    <Input
                      name="checkbox1"
                      type="checkbox"
                    />
                    {' '}
                    <Label check>
                    I hereby certify that all Information declared is true and connect to the best of my knowledge and belief.
                  </Label>
                </FormGroup>
              </Col>
            </Row>
            <Row form>
              <Col md={3}>
                <FormGroup>
                  <Label for="">Allowed %</Label>
                  <Input type="text" className="form-control" id="" />
                </FormGroup>
              </Col>
              <Col md={3}>
                <FormGroup>
                  <Label for="InputState">Status</Label>
                  <select id="InputState" className="form-control">
                    <option>Approved</option>
                  </select>
                </FormGroup>
              </Col>
              <Col md={6}>
                <FormGroup>
                  <Label for="">Remarks</Label>
                  <Input type="text" className="form-control" id="" />
                </FormGroup>
              </Col>
              <Col md={12} className="text-right">
                <FormGroup>
                  <Button color="primary">Update</Button>
                </FormGroup>
              </Col>
            </Row>
          </Form>
        </CardBody>
      </Card>
      <Card className="mb-3">
        <CardHeader>
          <h6 className="font-weight-bold mb-0">HOD Approval</h6>
        </CardHeader>
        <CardBody>
          <Form>
            <Row form>
              <Col md={3}>
                <FormGroup>
                  <Label for="">Allowed %</Label>
                  <Input type="text" className="form-control" id="" />
                </FormGroup>
              </Col>
              <Col md={3}>
                <FormGroup>
                  <Label for="InputState">Status</Label>
                  <select id="InputState" className="form-control">
                    <option >Approved</option>
                  </select>
                </FormGroup>
              </Col>
              <Col md={6}>
                <FormGroup>
                  <Label for="">Remarks</Label>
                  <Input type="text" className="form-control" id="" />
                </FormGroup>
              </Col>
            </Row>
            <Row form>
              <Col md={12} className="text-right">
                <FormGroup>
                  <Button color="primary">Update</Button>
                </FormGroup>
              </Col>
            </Row>
          </Form>
        </CardBody>
      </Card>
      <Card className="mb-3">
        <CardHeader>
          <h6 className="font-weight-bold mb-0">CEO Approval</h6>
        </CardHeader>
        <CardBody>
          <Form>
            <Row form>
              <Col md={3}>
                <FormGroup>
                  <Label for="">Allowed %</Label>
                  <Input type="text" className="form-control" id="" />
                </FormGroup>
              </Col>
              <Col md={3}>
                <FormGroup>
                  <Label for="InputState">Status</Label>
                  <select id="InputState" className="form-control">
                    <option >Approved</option>
                  </select>
                </FormGroup>
              </Col>
              <Col md={6}>
                <FormGroup>
                  <Label for="">Remarks</Label>
                  <Input type="text" className="form-control" id="" />
                </FormGroup>
              </Col>
            </Row>
            <Row form className="text-right">
              <Col md={12}>
                <FormGroup>
                  <Button color="primary">Update</Button>
                </FormGroup>
              </Col>
            </Row>
          </Form>
        </CardBody>
      </Card>
      <Card className="mb-3">
        <CardHeader>
          <h6 className="font-weight-bold mb-0">Accounts Approval</h6>
        </CardHeader>
        <CardBody>
          <Form>
            <Row form>
              <Col md={3}>
                <FormGroup>
                  <Label for="">Allowed %</Label>
                  <Input type="text" className="form-control" id="" />
                </FormGroup>
              </Col>
              <Col md={3}>
                <FormGroup>
                  <Label for="InputState">Status</Label>
                  <select id="InputState" className="form-control">
                    <option >Approved</option>
                  </select>
                </FormGroup>
              </Col>
              <Col md={6}>
                <FormGroup>
                  <Label for="">Remarks</Label>
                  <Input type="text" className="form-control" id="" />
                </FormGroup>
              </Col>
            </Row>
            <Row form className="text-right">
              <Col md={12}>
                <FormGroup>
                  <Button color="primary">Update</Button>
                </FormGroup>
              </Col>
            </Row>
          </Form>
        </CardBody>
      </Card>

    </div>
  );

}

export default Approvels