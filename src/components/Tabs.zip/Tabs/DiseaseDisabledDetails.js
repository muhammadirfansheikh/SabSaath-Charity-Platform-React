import React, { useState, Link } from 'react'
import { useHistory } from "react-router-dom";
import {
  Card,
  CardHeader,
  CardBody,
  CardTitle,
  Table,
  Row,
  Col,
  Button,
  FormGroup,
  Form,
  Label,
  Option,
  Input,
  check,
  Badge
} from "reactstrap";

const DiseaseDisabledDetails = (props) => {
  return (
    <div>
      <Card className="mb-3">
        <CardHeader>
          <h6 className="font-weight-bold mb-0">Disease/Disabled Details</h6>
        </CardHeader>
        <CardBody>
          <Form>
            <Row form>
              <Col md={5}>
                <FormGroup check>
                    <Input
                      name="IsDisableChecked"
                      type="checkbox"
                      checked={props.diseaseDisableValues.IsDisableChecked}
                      onChange={props.handleDiseaseInputChange}
                    />
                    {' '}
                    <Label check>
                      Is there a disabled person(s) in the house?
                    </Label>
                </FormGroup>
              </Col>
              <Col md={3}>
                <FormGroup>
                  <Label for="">Details</Label>
                  <Input type="textarea" Row={2} className="form-control" name="DisableDetailValue" value={props.diseaseDisableValues.DisableDetailValue} onChange={props.handleDiseaseInputChange} />
                </FormGroup>
              </Col>
            </Row>
            <Row form>
              <Col md={5}>
                  <FormGroup check>
                    <Input
                      name="IsDiseaseChecked"
                      type="checkbox"
                      checked={props.diseaseDisableValues.IsDiseaseChecked}
                      onChange={props.handleDiseaseInputChange}
                    />
                    {' '}
                    <Label check>
                      Does any family member have a medical condition?
                    </Label>
                  </FormGroup>
              </Col>
              <Col md={3}>
                <FormGroup>
                  <Label for="">Details</Label>
                  <Input type="textarea" Row={2} className="form-control" name="DiseaseDetailValue" value={props.diseaseDisableValues.DiseaseDetailValue} onChange={props.handleDiseaseInputChange} />
                </FormGroup>
              </Col>
            </Row>
          </Form>
        </CardBody>
      </Card>
      {/* <Row className="text-right">
        <Col md={12}>
          <FormGroup>
            <Button color="primary">Save</Button>
          </FormGroup>
        </Col>
      </Row> */}
    </div>
  );



}

export default DiseaseDisabledDetails