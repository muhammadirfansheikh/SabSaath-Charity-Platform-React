import React, { useState, Link } from 'react'
import { useHistory } from "react-router-dom";
import {
  Card,
  CardHeader,
  CardBody,
  CardTitle,
  Table,
  Row,
  Col,
  Button,
  FormGroup,
  Form,
  Label,
  Option,
  Input,
  check,
  Badge
} from "reactstrap";

const HomeAppliances = (props) => {
return(
<div>
<Card className="mb-3">
<CardHeader>
  <h5 className="font-weight-bold mb-0">Home Appliances</h5>
</CardHeader>
<CardBody>
  <Form>
    <div className="form-row">
      <div className="form-group col-md-3">
        <Label for="InputState">Does a household own a TV?</Label>
        <select id="InputState" className="form-control">
          <option selected="">yes</option>
        </select>
      </div>
      <div className="form-group col-md-3">
        <Label for="InputState">Does a household own a AC?</Label>
        <select id="InputState" className="form-control">
          <option selected="">yes</option>
        </select>
      </div>
      <div className="form-group col-md-3">
        <Label for="InputState">Does a household own a washing machine?</Label>
        <select id="InputState" className="form-control">
          <option selected="">yes</option>
        </select>
      </div>
      <div className="form-group col-md-3">
        <Label for="InputState">Does a household own a refrigerator?</Label>
        <select id="InputState" className="form-control">
          <option selected="">yes</option>
        </select>
      </div>
      <div className="form-group col-md-3">
        <Label for="InputState">Does a household own a sewing machine?</Label>
        <select id="InputState" className="form-control">
          <option selected="">yes</option>
        </select>
      </div>
      <div className="form-group col-md-3">
        <Label for="InputState">Does a household own a couch/sofa?</Label>
        <select id="InputState" className="form-control">
          <option selected="">yes</option>
        </select>
      </div>
      <div className="form-group col-md-3">
        <Label for="InputState">Does a household own a cycle, motorcycle, vehicle other?</Label>
        <select id="InputState" className="form-control">
          <option selected="">yes</option>
        </select>
      </div>
      <div className="form-group col-md-3">
        <Label for="InputState">Does a household own a gas heater?</Label>
        <select id="InputState" className="form-control">
          <option selected="">yes</option>
        </select>
      </div>
      <div className="form-group col-md-3">
        <Label for="InputState">Does a household own an air cooler?</Label>
        <select id="InputState" className="form-control">
          <option selected="">yes</option>
        </select>
      </div>
      <div className="form-group col-md-3">
        <Label for="InputState">Does a household own a dispencer?</Label>
        <select id="InputState" className="form-control">
          <option selected="">yes</option>
        </select>
      </div>
      <div className="form-group col-md-3">
        <Label for="InputState">Does a household own a smartphone?</Label>
        <select id="InputState" className="form-control">
          <option selected="">yes</option>
        </select>
      </div>
      <div className="form-group col-md-3">
        <Label for="">Other remarks/observation</Label>
        <Input type="text" className="form-control" id="" />
      </div>
    </div>
  </Form>
</CardBody>
</Card>
<div className="row float-right pb-3">
<div className="col-md-12">
  <button type="button" className="btn btn-primary ">Save</button>
</div>
</div>
</div>
    );



}

export default HomeAppliances