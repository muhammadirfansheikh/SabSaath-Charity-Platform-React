import React, { useState, Link } from 'react'
import { useHistory } from "react-router-dom";
import {
  Card,
  CardHeader,
  CardBody,
  CardTitle,
  Table,
  Row,
  Col,
  Button,
  FormGroup,
  Form,
  Label,
  Option,
  Input,
  check,
  Badge
} from "reactstrap";
import ModalApplHistory from '../../components/modal/ModalApplHistory.js'

const PrimarySupport = (props) => {

  const [openModal, setOpenModal] = useState(false);
  const openNewmodal = () => {
    
     setOpenModal(true);
   }
   const closeNewmodal = () => {
     setOpenModal(false);
   } 

  return (
    <div>
    <Row>
    <Col md={12} className="text-right">
      <Button color="secondary" className="btn-sm" type="submit" onClick={() => openNewmodal({ UserId: 0 })}>History</Button>
    </Col>
    </Row>
    {/*primary support*/} 
      <Card className="mb-3">
        <CardHeader>
          <h6 className="font-weight-bold mb-0">Primary Support</h6>
        </CardHeader>
        <CardBody>
          <Form>
            <Row form>
              <Col md={3}>
                <FormGroup>
                  <Label for="InputState">Category</Label>
                  <select id="InputState" className="form-control">
                    <option selected="">Education</option>
                  </select>
                </FormGroup>
              </Col>
              <Col md={3}>
                <FormGroup>
                  <Label for="InputState">Fund Category</Label>
                  <select id="InputState" className="form-control">
                    <option selected="">Scholarship</option>
                  </select>
                </FormGroup>
              </Col>
              <Col md={3}>
                <FormGroup>
                  <Label for="InputState">Frequency</Label>
                  <select id="InputState" className="form-control">
                    <option selected="">Quarterly</option>
                  </select>
                </FormGroup>
              </Col>
              <Col md={3}>
                <FormGroup>
                  <Label for="">Repetition</Label>
                  <Input type="text" className="form-control" id="" />
                </FormGroup>
              </Col>
              <Col md={3}>
                <FormGroup>
                  <Label for="">Fund required</Label>
                  <Input type="text" className="form-control" id="" />
                </FormGroup>
              </Col>
              <Col md={3}>
                <FormGroup>
                  <Label for="InputDate">Start Date</Label>
                  <Input type="date" className="form-control" id="InputDate" />
                </FormGroup>
              </Col>
              <Col md={3}>
                <FormGroup>
                  <Label for="InputDate">Expiry Date</Label>
                  <Input type="date" className="form-control" id="InputDate" />
                </FormGroup>
              </Col>
              <Col md={3}>
                <FormGroup>
                  <Label for="InputState">Payment Type</Label>
                  <select id="InputState" className="form-control">
                    <option selected="">Cash</option>
                  </select>
                </FormGroup>
           </Col>
           <Col md={3}>
                <FormGroup>
                  <Label for="InputDate">Reinvestigation Date</Label>
                  <Input type="date" className="form-control" id="InputDate" />
                </FormGroup>
              </Col>
              <Col md={3}>
                <FormGroup>
                  <Label for="">Remarks</Label>
                  <Input type="text" className="form-control" id="" />
                </FormGroup>
              </Col>
              
              
            </Row>
            <Row Form className="text-right">
              <Col md={12}>
                <FormGroup>
                  <Button color="primary">Add</Button>
                </FormGroup>
              </Col>
            </Row>
          </Form>

        
          <Row>
            <Col md={12}>
              <h2 className="h6">Primary Support Details</h2>
            </Col>
          </Row>
          <Row>
            <Col md={12}>
              <Table bordered striped responsive>
                <thead>
                  <tr>
                    <th>Sr #</th>
                    <th>Category</th>
                    <th>Fund Category</th>
                    <th>Frequency</th>
                    <th>Repetition</th>
                    <th>Fund Required</th>
                    <th>Start Date</th>
                    <th>Expiry Date</th>
                    <th>Payment Type</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>1</td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td><Button color="primary" outline size="sm"><i className="nc-icon nc-ruler-pencil"></i></Button>
                    <Button color="danger" outline size="sm"><i className="nc-icon nc-simple-remove"></i></Button></td>
                  </tr>
                 
                 
                </tbody>
              </Table>
            </Col>
          </Row>
        </CardBody>
      </Card>
     {/*primary support*/} 
     <Form>
     <Row Form>
     <Col md={4}>
       <FormGroup>
         <div className="form-check-inline ml-3">
           <Label className="form-check-Label">
           <Input type="checkbox" className="form-check-Input" />Additional Support Required
           </Label>
         </div>
       </FormGroup>
     </Col>
     </Row>
     </Form>


       {/*Secondary support*/} 

       <Card className="mb-3">
        <CardHeader>
          <h6 className="font-weight-bold mb-0">Secondary Support</h6>
        </CardHeader>
        <CardBody>
          <Form>
            <Row form>
              <Col md={3}>
                <FormGroup>
                  <Label for="InputState">Category</Label>
                  <select id="InputState" className="form-control">
                    <option selected="">Education</option>
                  </select>
                </FormGroup>
              </Col>
              <Col md={3}>
                <FormGroup>
                  <Label for="InputState">Fund Category</Label>
                  <select id="InputState" className="form-control">
                    <option selected="">Scholarship</option>
                  </select>
                </FormGroup>
              </Col>
              <Col md={3}>
                <FormGroup>
                  <Label for="InputState">Frequency</Label>
                  <select id="InputState" className="form-control">
                    <option selected="">Quarterly</option>
                  </select>
                </FormGroup>
              </Col>
              <Col md={3}>
                <FormGroup>
                  <Label for="">Repetition</Label>
                  <Input type="text" className="form-control" id="" />
                </FormGroup>
              </Col>
              <Col md={3}>
                <FormGroup>
                  <Label for="">Fund required</Label>
                  <Input type="text" className="form-control" id="" />
                </FormGroup>
              </Col>
              <Col md={3}>
                <FormGroup>
                  <Label for="InputDate">Start Date</Label>
                  <Input type="date" className="form-control" id="InputDate" />
                </FormGroup>
              </Col>
              <Col md={3}>
                <FormGroup>
                  <Label for="InputDate">Expiry Date</Label>
                  <Input type="date" className="form-control" id="InputDate" />
                </FormGroup>
              </Col>
              <Col md={3}>
                <FormGroup>
                  <Label for="InputState">Payment Type</Label>
                  <select id="InputState" className="form-control">
                    <option selected="">Cash</option>
                  </select>
                </FormGroup>
              </Col>
              <Col md={3}>
                <FormGroup>
                  <Label for="">Remarks</Label>
                  <Input type="text" className="form-control" id="" />
                </FormGroup>
              </Col>
            </Row>
            <Row Form className="text-right">
              <Col md={12}>
                <FormGroup>
                  <Button color="primary">Add</Button>
                </FormGroup>
              </Col>
            </Row>
          </Form>
          <Row>
            <Col md={12}>
              <h2 className="h6">Secondary Support Details</h2>
            </Col>
          </Row>
          <Row>
            <Col md={12}>
              <Table bordered striped responsive>
                <thead>
                  <tr>
                    <th>Sr #</th>
                    <th>Category</th>
                    <th>Fund Category</th>
                    <th>Frequency</th>
                    <th>Repetition</th>
                    <th>Fund Required</th>
                    <th>Start Date</th>
                    <th>Expiry Date</th>
                    <th>Payment Type</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>1</td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td><Button color="primary" outline size="sm"><i className="nc-icon nc-ruler-pencil"></i></Button>
                    <Button color="danger" outline size="sm"><i className="nc-icon nc-simple-remove"></i></Button></td>
                  </tr>
                  <tr>
                    <td>2</td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td><Button color="primary" outline size="sm"><i className="nc-icon nc-ruler-pencil"></i></Button>
                     <Button color="danger" outline size="sm"><i className="nc-icon nc-simple-remove"></i></Button></td>
                  </tr>
                  <tr>
                    <td>3</td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                     <td><Button color="primary" outline size="sm"><i className="nc-icon nc-ruler-pencil"></i></Button>
                     <Button color="danger" outline size="sm"><i className="nc-icon nc-simple-remove"></i></Button></td>
                  </tr>
                 
                </tbody>
              </Table>
            </Col>
          </Row>
            <Row className="row justify-content-end pt-3">
             <Col md={3}>
             <Label for="">Total Fund Required</Label>
             <Input type="number" className="form-control" id="" />
             </Col>
            </Row>

        </CardBody>
      </Card>

        {/*Secondary support*/} 


      {/* <Row className="text-right">
        <Col md={12}>
          <Button color="primary">Create</Button>
        </Col>
      </Row> */}
      {
      openModal &&
      <ModalApplHistory {...props}
        HeaderText="Applicant History"
        Ismodalshow={openModal}
        closeNewmodal={closeNewmodal}
      />

    }
    </div>
  );



}

export default PrimarySupport