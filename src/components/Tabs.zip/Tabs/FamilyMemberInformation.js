import React, { useState, Link } from 'react'
import { useHistory } from "react-router-dom";
import {
  Card,
  CardHeader,
  CardBody,
  CardTitle,
  Table,
  Row,
  Col,
  Button,
  FormGroup,
  Form,
  Label,
  Option,
  Input,
  check,
  Badge
} from "reactstrap";

// import { fetchData } from '../utils/Api.js'
// import { ApiMethods,ControllerName,OperationTypeId,SetupMasterIds,Roles } from '../utils/Constants.js'

const FamilyMemberInformation = (props) => {

  const AddFamilyDataOnGrid=(e)=>{
e.preventDefault();
debugger;
//var setupdetailname=props.familyValues.RelationList.filter(p => p.SetupDetailId ===props.familyValues.RelationId)[0].SetupDetailName;
    var FamilyGriddata=props.familyValues.FamilyDetailGridList===undefined?[]:props.familyValues.FamilyDetailGridList;
    
    if(props.familyValues.Name==="" )
    {
    alert("Must Fill The Name");
    }
    else{
        FamilyGriddata.push({FamilyMemberNo:props.familyValues.FamilyMemberNo,Name:props.familyValues.Name
      ,Cnic:props.familyValues.Cnic,DOB:props.familyValues.DOB,Remarks:props.familyValues.Remarks
      ,IsEmployed:props.familyValues.IsEmployed,Earnings:props.familyValues.Earnings,DetailsOfEarning:props.familyValues.DetailsOfEarning
      ,RelationId:props.familyValues.RelationId,MaritalStatusId:props.familyValues.MaritalStatusId});

      console.log("FamilyGriddata",FamilyGriddata);
      props.handleFamilyGridChange(FamilyGriddata);

    }
  }

function GetSetupDetail_IdOrName(SetupDetailId,SetupDetailName,SetupDetailList) {
  console.log("FamilyInformation GetSetupDetail");
  console.log("FamilyInformation GetSetupDetail values",SetupDetailId,SetupDetailName,SetupDetailList);
  var filterdata="";
  if(SetupDetailId>0 && SetupDetailId!=undefined && SetupDetailId!=null)
  {
   filterdata= SetupDetailList.filter(p => p.SetupDetailId ===parseInt(SetupDetailId))[0].SetupDetailName;
  console.log("filterdata",filterdata);
  return filterdata;
  }
  else if(SetupDetailName!=null && SetupDetailName!="" && SetupDetailName!=undefined)
  {
   filterdata= SetupDetailList.filter(p => p.SetupDetailName ===SetupDetailName)[0].SetupDetailId;
   console.log("filterdata",filterdata);
  return filterdata;
  }
  return filterdata;
}

return(
<div>
<Card className="mb-3">
<CardHeader>
<h6 className="font-weight-bold mb-0">Family Member Information</h6>
</CardHeader>
<CardBody>
  <Form>
    <Row form>
      <Col md={3}>
        <FormGroup>
          <Label for="">Family Member ID</Label>
          <Input type="text" className="form-control" name="FamilyMemberNo" value={props.familyValues.FamilyMemberNo} onChange={props.handleFamilyInputChange} />
        </FormGroup>
      </Col>
      <Col md={3}>
        <FormGroup>
          <Label for="">Name*</Label>
          <Input type="text" className="form-control" name="Name" value={props.familyValues.Name} onChange={props.handleFamilyInputChange} />
        </FormGroup>
      </Col>
      <Col md={3}>
        <FormGroup>
          <Label for="">Relation*</Label>
          <Input type="select" className="form-control" name="RelationId" value={props.familyValues.RelationId} onChange={props.handleFamilyInputChange}>
          <option key={0} value={0} >Select</option>
            {
              props.familyValues.RelationList &&
                            props.familyValues.RelationList.map((item, key) => (
                              <option key={item.SetupDetailId} value={item.SetupDetailId}>
                                {item.SetupDetailName}
                              </option>
                            ))
                          }  
          </Input>
        </FormGroup>
      </Col>
      <Col md={3}>
        <FormGroup>
          <Label for="">CNIC /Bayform Number*</Label>
          <Input type="number" className="form-control" name="Cnic" value={props.familyValues.Cnic} onChange={props.handleFamilyInputChange} />
        </FormGroup>
      </Col>
      <Col md={3}>
        <FormGroup>
          <Label for="InputDate">Date of Birth*</Label>
          <Input type="date" className="form-control" name="DOB" value={props.familyValues.DOB} onChange={props.handleFamilyInputChange} />
        </FormGroup>
      </Col>
      <Col md={3}>
        <FormGroup>
          <Label for="InputState">Marital Status</Label>
          <Input type="select" className="form-control" name="MaritalStatusId" value={props.familyValues.MaritalStatusId} onChange={props.handleFamilyInputChange}>
            <option key={0} value={0} >Select</option>
            {
              props.familyValues.MaritalList &&
                            props.familyValues.MaritalList.map((item, key) => (
                              <option key={item.SetupDetailId} value={item.SetupDetailId}>
                                {item.SetupDetailName}
                              </option>
                            ))
                          }  
         
          </Input>
        </FormGroup>
      </Col>
      <Col md={3}>
        <FormGroup>
          <Label for="">Earnings*</Label>
          <Input type="text" className="form-control" name="Earnings" value={props.familyValues.Earnings} onChange={props.handleFamilyInputChange} />
        </FormGroup>
      </Col>
      <Col md={3}>
        <FormGroup>
          <Label for="">Details of Earnings*</Label>
          <Input type="text" className="form-control" name="DetailsOfEarning" value={props.familyValues.DetailsOfEarning} onChange={props.handleFamilyInputChange} />
        </FormGroup>
      </Col>
      
    </Row>
    <Row form>
    <Col md={6}>
        <FormGroup>
          <Label for="">Remarks*</Label>
          <Input type="text" className="form-control" name="Remarks" value={props.familyValues.Remarks} onChange={props.handleFamilyInputChange} />
        </FormGroup>
      </Col>
    <Col md={6}>
        <FormGroup>
          <div className="form-check-inline mt-3 pt-3">
            <Label className="form-check-Label">
              <Input type="checkbox" className="form-check-Input" name="IsEmployed" checked={props.familyValues.IsEmployed} onChange={props.handleFamilyInputChange} />Employed
            </Label>
          </div>
        </FormGroup>
      </Col>
    </Row>
    <Row form className="text-right">
      <Col md={12}>
        <FormGroup>
          <Button color="primary" onClick={AddFamilyDataOnGrid} >Add</Button>
        </FormGroup>
      </Col>
    </Row>
  </Form>
  <Row>
<Col md={12}>
  <h2 className="h6">Family Information</h2>
</Col>
</Row>
<Row>
<Col md={12}>
  <table className="table">
    <thead>
      <tr>
       
        <th>Family Member ID</th>
        <th>Name</th>
        <th>Relation</th>
        <th>CNIC/Bay form Number</th>
        <th>Date of Birth</th>
        <th>Marital Status</th>
        <th>Is Emplyeed</th>
        <th>Earnings</th>
        <th>Details of Earnings</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
    {
      //<td>{props.familyValues.RelationList && props.familyValues.RelationList.filter(p => p.SetupDetailId ===parseInt(props.familyValues.RelationId))[0].SetupDetailName}</td>
      // <td>{props.familyValues.MaritalList && props.familyValues.MaritalList.filter(p => p.SetupDetailId ===parseInt(props.familyValues.MaritalStatusId))[0].SetupDetailName}</td>
      //<td>{()=>GetSetupDetail_IdOrName(props.familyValues.RelationId,"",props.familyValues.RelationList)}</td>
      //<td>{()=>GetSetupDetail_IdOrName(props.familyValues.MaritalStatusId,"",props.familyValues.MaritalList)}</td>
              props.familyValues.FamilyDetailGridList &&
                            props.familyValues.FamilyDetailGridList.map((item, key) => (
                              <tr key={key}>
                              <td>{item.FamilyMemberNo}</td>
                              <td>{item.Name}</td>
                              <td>{GetSetupDetail_IdOrName(item.RelationId,"",props.familyValues.RelationList)}</td>
                              <td>{item.Cnic}</td>
                              <td>{item.DOB}</td>
                              <td>{GetSetupDetail_IdOrName(item.MaritalStatusId,"",props.familyValues.MaritalList)}</td>
                              <td>{item.IsEmployed===true?"Yes":"No"}</td>
                              <td>{item.Earnings}</td>
                              <td>{item.DetailsOfEarning}</td>
                              </tr>
                            ))
                          }  
     
     
    </tbody>
  </table>
</Col>
</Row>
<Row className="row justify-content-end pt-3">
<Col md={3}>
  <Label for="">Total Earnings</Label>
  <Input type="number" className="form-control" id="" />
  </Col>
</Row>
</CardBody>
</Card>



  </div>
    );



}

export default FamilyMemberInformation