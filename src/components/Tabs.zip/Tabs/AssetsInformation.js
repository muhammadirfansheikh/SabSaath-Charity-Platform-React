import React, { useState, Link } from 'react'
import { useHistory } from "react-router-dom";
import {
  Card,
  CardHeader,
  CardBody,
  CardTitle,
  Table,
  Row,
  Col,
  Button,
  FormGroup,
  Form,
  Label,
  Option,
  Input,
  check,
  Badge
} from "reactstrap";
import ModalApplHistory from '../../components/modal/ModalApplHistory.js'

const AssetsInformation = (props) => {

  const [openModal, setOpenModal] = useState(false);
 const openNewmodal = () => {
   
    setOpenModal(true);
  }
  const closeNewmodal = () => {
    setOpenModal(false);
  } 

  return (
    <div>
    <Row>
    <Col md={12} className="text-right">
      <Button color="secondary" className="btn-sm" type="submit" onClick={() => openNewmodal({ UserId: 0 })}>History</Button>
    </Col>
    </Row>
      <Card className="mb-3">
        <CardHeader>
          <h6 className="font-weight-bold mb-0">Assets Information</h6>
        </CardHeader>
        <CardBody>
          <Form>
            <Row form className="mb-3">
            <Col md={3}>
                <FormGroup>
                  <Label for="InputState">Asset Type</Label>
                  <select id="InputState" className="form-control">
                    <option selected="">Property</option>
                    <option selected="">Vehicle</option>
                    <option selected="">Jewellery</option>
                  </select>
                </FormGroup>
              </Col>
              <Col md={3}>
                <FormGroup>
                  <Label for="InputState">Asset Status</Label>
                  <select id="InputState" className="form-control">
                    <option selected="">Own</option>
                  </select>
                </FormGroup>
              </Col>
              <Col md={3}>
                <FormGroup>
                  <Label for="">Asset Details</Label>
                  <Input type="text" className="form-control" id="" />
                </FormGroup>
              </Col>
              <Col md={3}>
                <FormGroup>
                  <Label for="">Remarks</Label>
                  <Input type="text" className="form-control" id="" />
                </FormGroup>
              </Col>
              </Row>

               {/*if rent row*/}
               <Row form>
               <Col md={12}>
                <h2 className="h6">If Rent</h2>
               </Col>
             </Row>

             <Row form>
              <Col md={3}>
                <FormGroup>
                  <Label for="">Rent Amount</Label>
                  <Input type="number" className="form-control" id="" />
                </FormGroup>
              </Col>  
              </Row>
               {/*if rent row*/}

                {/*if mortage row*/}
              <Row form>
               <Col md={12}>
                <h2 className="h6">If Mortgage</h2>
               </Col>
             </Row>

             <Row form>
              <Col md={3}>
                <FormGroup>
                  <Label for="">Mortgage Detail</Label>
                  <Input type="text" className="form-control" id="" />
                </FormGroup>
              </Col>
              </Row>
               {/*if mortage row*/}


               {/*<Row form className="mb-3">
             <Col md={3}>
             <FormGroup check className="mt-1 pt-3">
                <Input
                  name="checkbox1"
                  type="checkbox" />
                <Label check>
                Vehicle
              </Label>
             </FormGroup>
           </Col>
              <Col md={3}>
                <FormGroup>
                  <Label for="InputState">Status</Label>
                  <select id="InputState" className="form-control">
                    <option selected="">Own</option>
                  </select>
                </FormGroup>
              </Col>
              <Col md={3}>
                <FormGroup>
                  <Label for="">Vehicle Detail</Label>
                  <Input type="text" className="form-control" id="" />
                </FormGroup>
              </Col>
              </Row>

               {/*if rent row
               <Row form>
               <Col md={12}>
                <h2 className="h6">If Rent</h2>
               </Col>
             </Row>

             <Row form>
              <Col md={3}>
                <FormGroup>
                  <Label for="">Rent Amount</Label>
                  <Input type="number" className="form-control" id="" />
                </FormGroup>
              </Col>  
              </Row>
               if rent row*/}

                {/*if mortage row
              <Row form>
               <Col md={12}>
                <h2 className="h6">If Mortgage</h2>
               </Col>
             </Row>

             <Row form>
              <Col md={3}>
                <FormGroup>
                  <Label for="">Mortgage Detail</Label>
                  <Input type="text" className="form-control" id="" />
                </FormGroup>
              </Col>
              </Row>
               if mortage row*/}

               {/*
               <Row form className="mb-3">
            <Col md={3}>
             <FormGroup check className="mt-1 pt-3">
                <Input
                  name="checkbox1"
                  type="checkbox" />
                <Label check>
                Jewellery
              </Label>
             </FormGroup>
           </Col>
              <Col md={3}>
                <FormGroup>
                  <Label for="InputState">Status</Label>
                  <select id="InputState" className="form-control">
                    <option selected="">Mortgage</option>
                  </select>
                </FormGroup>
              </Col>
              <Col md={3}>
                <FormGroup>
                  <Label for="">Mortgage Detail</Label>
                  <Input type="text" className="form-control" id="" />
                </FormGroup>
              </Col>
              </Row>
              
               <Row Form className="text-right">
               <Col md={12}>
                <FormGroup>
                  <Button color="primary">Add</Button>
                </FormGroup>
              </Col>
               </Row>*/}
          </Form>

          <Row>
            <Col md={12}>
              <h2 className="h6 pt-3">Asset Details</h2>
            </Col>
          </Row>
          <Row>
            <Col md={12}>
              <Table bordered striped responsive>
                <thead>
                  <tr>
                    <th>Sr #</th>
                    <th>Asset Type</th>
                    <th>Asset Details</th>
                    <th>Asset Status</th>
                    <th>Rent Amount</th> 
                    <th>Mortage Details</th> 
                    <th>Remarks</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>1</td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td><Button color="primary" outline size="sm"><i className="nc-icon nc-ruler-pencil"></i></Button>
                     <Button color="danger" outline size="sm"><i className="nc-icon nc-simple-remove"></i></Button></td>
                  </tr>
                  <tr>
                    <td>2</td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td><Button color="primary" outline size="sm"><i className="nc-icon nc-ruler-pencil"></i></Button>
                    <Button color="danger" outline size="sm"><i className="nc-icon nc-simple-remove"></i></Button></td>
                  </tr>
                  <tr>
                    <td>3</td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td><Button color="primary" outline size="sm"><i className="nc-icon nc-ruler-pencil"></i></Button>
                     <Button color="danger" outline size="sm"><i className="nc-icon nc-simple-remove"></i></Button></td>
                  </tr>
                  <tr>
                    <td>4</td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td><Button color="primary" outline size="sm"><i className="nc-icon nc-ruler-pencil"></i></Button>
                     <Button color="danger" outline size="sm"><i className="nc-icon nc-simple-remove"></i></Button></td>
                  </tr>
                </tbody>
              </Table>
            </Col>
          </Row>
        </CardBody>
      </Card>

      <Card className="mb-3">
        <CardHeader>
          <h6 className="font-weight-bold mb-0">Home Appliances</h6>
        </CardHeader>
        <CardBody>
          <Form>
            <Row form>
            <Col md={4}>
                <FormGroup>
                  <div className="form-check-inline mt-3 pt-3">
                    <Label className="form-check-Label">
                      <Input
                        type="checkbox"
                        className="form-check-Input" />
                      Does the household own a TV?
                    </Label>
                  </div>
                </FormGroup>
              </Col>
              <Col md={4}>
                <FormGroup>
                  <div className="form-check-inline mt-3 pt-3">
                    <Label className="form-check-Label">
                      <Input
                        type="checkbox"
                        className="form-check-Input" />
                      Does the household own a AC?
                    </Label>
                  </div>
                </FormGroup>
              </Col>
              <Col md={4}>
                <FormGroup>
                  <div className="form-check-inline mt-3 pt-3">
                    <Label className="form-check-Label">
                      <Input
                        type="checkbox"
                        className="form-check-Input" />
                      Does the household own a washing machine?
                    </Label>
                  </div>
                </FormGroup>
              </Col>
              <Col md={4}>
                <FormGroup>
                  <div className="form-check-inline mt-3 pt-3">
                    <Label className="form-check-Label">
                      <Input
                        type="checkbox"
                        className="form-check-Input" />
                      Does the household own a smart phone?
                    </Label>
                  </div>
                </FormGroup>
              </Col>
              <Col md={4}>
                <FormGroup>
                  <div className="form-check-inline mt-3 pt-3">
                    <Label className="form-check-Label">
                      <Input
                        type="checkbox"
                        className="form-check-Input" />
                      Does the household own a sewing machine?
                    </Label>
                  </div>
                </FormGroup>
              </Col>
              <Col md={4}>
                <FormGroup>
                  <div className="form-check-inline mt-3 pt-3">
                    <Label className="form-check-Label">
                      <Input
                        type="checkbox"
                        className="form-check-Input" />
                      Does the household own a couch/sofa?
                    </Label>
                  </div>
                </FormGroup>
              </Col>
              <Col md={4}>
                <FormGroup>
                  <div className="form-check-inline mt-3 pt-3">
                    <Label className="form-check-Label">
                      <Input
                        type="checkbox"
                        className="form-check-Input" />
                      Does the household own a gas heater?
                    </Label>
                  </div>
                </FormGroup>
              </Col>
              <Col md={4}>
                <FormGroup>
                  <div className="form-check-inline mt-3 pt-3">
                    <Label className="form-check-Label">
                      <Input
                        type="checkbox"
                        className="form-check-Input" />
                      Does the household own a refrigerator?
                    </Label>
                  </div>
                </FormGroup>
              </Col>

              <Col md={4}>
                <FormGroup>
                  <div className="form-check-inline mt-3 pt-3">
                    <Label className="form-check-Label">
                      <Input
                        type="checkbox"
                        className="form-check-Input" />
                      Does the household own an air cooler?
                    </Label>
                  </div>
                </FormGroup>
              </Col>
              <Col md={4}>
                <FormGroup>
                  <div className="form-check-inline mt-3 pt-3">
                    <Label className="form-check-Label">
                      <Input
                        type="checkbox"
                        className="form-check-Input" />
                      Does the household own an dispenser?
                    </Label>
                  </div>
                </FormGroup>
              </Col>
              <Col md={4}>
                <FormGroup>
                  <Label for="">Any other details</Label>
                  <Input type="text" className="form-control" id="" />
                </FormGroup>
              </Col>
            </Row>

          </Form>
        </CardBody>
      </Card>
      {/* <Row className="text-right">
        <Col md={12}>
          <Button color="primary">Save</Button>
        </Col>
      </Row> */}
      {
      openModal &&
      <ModalApplHistory {...props}
        HeaderText="Applicant History"
        Ismodalshow={openModal}
        closeNewmodal={closeNewmodal}
      />

    }
    </div>
  );

}

export default AssetsInformation