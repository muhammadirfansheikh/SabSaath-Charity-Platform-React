import React, { useState, Link } from 'react'
import { useHistory } from "react-router-dom";
import {
  Card,
  CardHeader,
  CardBody,
  CardTitle,
  Table,
  Row,
  Col,
  Button,
  FormGroup,
  Form,
  Label,
  Option,
  Input,
  check,
  Badge
} from "reactstrap";

const LoanDetails = (props) => {

  const onDelete=(LoanTypeId,e)=>{
    debugger;
    e.preventDefault();
    console.log(LoanTypeId);
  };

  const AddLoanInGrid=(e)=>{
    debugger;
  e.preventDefault();
  var alreadyexists=false;
  var LoanGridData=props.loanValues.LoanGrid===undefined?[]:props.loanValues.LoanGrid;
  if(props.loanValues.Purpose==='' || props.loanValues.LoanAmount<=0 || props.loanValues.LoanTypeId<=0 
  || props.loanValues.DurationInMonth<=0|| props.loanValues.MonthlyInstallment<=0 
  || props.loanValues.StartDate===''|| props.loanValues.EndDate==='' || props.loanValues.Remarks==='')
  {
    alert("Must fill the fields");
  }
  else if(new Date(props.loanValues.StartDate)> new Date(props.loanValues.EndDate))
  {
    alert("Start Date must be less than end date");
  }
  else
  {
    if(LoanGridData.length>0){
            alreadyexists=LoanGridData.some(el => el.LoanTypeId === props.loanValues.LoanTypeId);
            alreadyexists && alert("Already Exists");
    }
    if(!alreadyexists){
       LoanGridData.push({LoanTypeId:props.loanValues.LoanTypeId
       ,LoanType:GetSetupDetail_Name(props.loanValues.LoanTypeId,props.loanValues.LoanTypeddlList)
       ,Purpose:props.loanValues.Purpose,CommitteAmount:props.loanValues.LoanAmount
       ,DurationInMonth:props.loanValues.DurationInMonth,MonthlyInstallment:props.loanValues.MonthlyInstallment,
       StartDate:props.loanValues.StartDate,EndDate:props.loanValues.EndDate,Remarks:props.loanValues.Remarks});

      console.log("LoanGridData",LoanGridData);
      props.handleLoanGridChange(LoanGridData);
    }
  }
  };
function GetSetupDetail_Name(SetupDetailId,SetupDetailList) {
  var filterdata="";
  if(SetupDetailId>0 && SetupDetailId!=undefined && SetupDetailId!=null)
  {
   filterdata= SetupDetailList.filter(p => p.SetupDetailId ===parseInt(SetupDetailId))[0].SetupDetailName;
  console.log("filterdata",filterdata);
  return filterdata;
  }
  
  return filterdata;
}
const AddCommitteInGrid=(e)=>{
   debugger;
  e.preventDefault();
  console.log(props.committeValues);
  var alreadyexists=false;
  var CommitteGridData=props.committeValues.CommitteGrid===undefined?[]:props.committeValues.CommitteGrid;
  if(props.committeValues.Purpose==='' || props.committeValues.CommitteAmount<=0 
  || props.committeValues.DurationInMonth<=0|| props.committeValues.MonthlyInstallment<=0 
  || props.committeValues.StartDate===''|| props.committeValues.EndDate==='' || props.committeValues.Remarks==='')
  {
    alert("Must fill the fields");
  }
  else if(new Date(props.committeValues.StartDate)> new Date(props.committeValues.EndDate))
  {
    alert("Start Date must be less than end date");
  }
  else
  {
    if(CommitteGridData.length>0){
            alreadyexists=CommitteGridData.some(el => el.Purpose === props.committeValues.Purpose);
            alreadyexists && alert("Already Exists");
    }
    if(!alreadyexists){
       CommitteGridData.push({Purpose:props.committeValues.Purpose,CommitteAmount:props.committeValues.CommitteAmount
       ,DurationInMonth:props.committeValues.DurationInMonth,MonthlyInstallment:props.committeValues.MonthlyInstallment,
       StartDate:props.committeValues.StartDate,EndDate:props.committeValues.EndDate,Remarks:props.committeValues.Remarks});

      console.log("CommitteGridData",CommitteGridData);
      props.handleCommitteGridChange(CommitteGridData);
    }
  }
    
  };

const onDeleteCommitte=(Purpose,e)=>{
  e.preventDefault();
  debugger;
console.log(Purpose);
    var listCommitteGrid=props.committeValues.CommitteGrid;
    const indx = listCommitteGrid.findIndex(v => v.Purpose === Purpose);
listCommitteGrid.splice(indx, indx >= 0 ? 1 : 0);
props.handleCommitteGridChange(listCommitteGrid);
  };

return(
<div>
    <Row className="text-right">
    <Col md={12}>
      <Button className="btn-sm">History</Button>
    </Col>
    </Row>
      <Card className="mb-3">
        <CardHeader>
          <h6 className="font-weight-bold mb-0">Loan Details</h6>
        </CardHeader>
        <CardBody>
          <Form>
           
            <Row form>
            <Col md={3}>
          <FormGroup>
            <Label for="InputState">Loan Type</Label>
            <Input type="select" className="form-control" name="LoanTypeId" value={props.loanValues.LoanTypeId} onChange={props.handleLoanInputChange}>
            <option key={0} value={0} >Select</option>
            {
              props.loanValues.LoanTypeddlList &&
                            props.loanValues.LoanTypeddlList.map((item, key) => (
                              <option key={item.SetupDetailId} value={item.SetupDetailId}>
                                {item.SetupDetailName}
                              </option>
                            ))
                          }  
          </Input>
          </FormGroup>
          </Col>
              <Col md={3}>
                <FormGroup>
                  <Label for="">Purpose?</Label>
                  <Input type="text" className="form-control" name="Purpose" value={props.loanValues.Purpose} onChange={props.handleLoanInputChange} />
                </FormGroup>
              </Col>
              <Col md={3}>
                <FormGroup>
                  <Label for="">Loan Amount</Label>
                  <Input type="text" className="form-control" name="LoanAmount" value={props.loanValues.LoanAmount} onChange={props.handleLoanInputChange} />
                </FormGroup>
              </Col>
              <Col md={3}>
                <FormGroup>
                  <Label for="">Duration In Month</Label>
                  <Input type="text" className="form-control" name="DurationInMonth" value={props.loanValues.DurationInMonth} onChange={props.handleLoanInputChange} />
                </FormGroup>
              </Col>
              <Col md={3}>
                <FormGroup>
                  <Label for="">Monthly installment</Label>
                  <Input type="number" className="form-control" name="MonthlyInstallment" value={props.loanValues.MonthlyInstallment} onChange={props.handleLoanInputChange} />
                </FormGroup>
              </Col>
              <Col md={3}>
              <FormGroup>
               <Label for="InputDate">Start Date</Label>
              <Input type="date" className="form-control" id="InputDate" name="StartDate" value={props.loanValues.StartDate} onChange={props.handleLoanInputChange} />
              </FormGroup>
              </Col>
              <Col md={3}>
              <FormGroup>
               <Label for="InputDate">End Date</Label>
              <Input type="date" className="form-control" id="InputDate" name="EndDate" value={props.loanValues.EndDate} onChange={props.handleLoanInputChange} />
              </FormGroup>
              </Col>
              <Col md={3}>
                <FormGroup>
                  <Label for="">Remarks</Label>
                  <Input type="text" className="form-control" name="Remarks" value={props.loanValues.Remarks} onChange={props.handleLoanInputChange} />
                </FormGroup>
              </Col>
            </Row>
            <Row  className="text-right">
              <Col md={12}>
                <FormGroup>
                  <Button color="primary" onClick={(e)=>AddLoanInGrid(e)} >Add</Button>
                </FormGroup>
              </Col>
            </Row>
          </Form>
          <Row>
            <Col md={12}>
              <h2 className="h6">Loan Details</h2>
            </Col>
          </Row>
          <Row>
            <Col md={12}>
              <Table bordered striped responsive>
                <thead>
                  <tr>
                    <th>Sr #</th>
                    <th>Loan Type</th>
                    <th>Purpose</th>
                    <th>Loan Amount</th>
                    <th>Duration</th>
                    <th>Monthly Installment</th>
                    <th>Start Date</th>
                    <th>End Date</th>
                    <th>Remarks</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                 {
            props.loanValues.LoanGrid &&
                            props.loanValues.LoanGrid.map((item, key) => (
                              <tr key={key+1}>
                               <td>{key+1}</td>
                             <td>{item.LoanType}</td>
                              <td>{item.Purpose}</td>
                              <td>{item.LoanAmount}</td>
                              <td>{item.Duration}</td>
                              <td>{item.MonthlyInstallment}</td>
                              <td>{item.StartDate}</td>
                              <td>{item.EndDate}</td>
                              <td>{item.Remarks}</td>
                               <td>
                          <Button color="danger" outline size="sm" onClick={(e) => onDelete(item.LoanTypeId,e)}><i className="nc-icon nc-simple-remove"></i></Button>
                        </td>
                              </tr>
                            ))
                          }  
                </tbody>
              </Table>
            </Col>
          </Row>
        </CardBody>
      </Card>
      {/* <Row className="text-right">
        <Col md={12} >
          <Button color="primary">Save</Button>
        </Col>
      </Row> */}

<Card className="mb-3">
        <CardHeader>
          <h6 className="font-weight-bold mb-0">Committe Details</h6>
        </CardHeader>
        <CardBody>
          <Form>
           
            <Row form>
              <Col md={3}>
                <FormGroup>
                  <Label for="">Purpose?</Label>
                  <Input type="text" className="form-control" name="Purpose" value={props.committeValues.Purpose} onChange={props.handleCommitteInputChange} />
                </FormGroup>
              </Col>
              <Col md={3}>
                <FormGroup>
                  <Label for="">Committe Amount</Label>
                  <Input type="text" className="form-control" name="CommitteAmount" value={props.committeValues.CommitteAmount} onChange={props.handleCommitteInputChange} />
                </FormGroup>
              </Col>
              <Col md={3}>
                <FormGroup>
                  <Label for="">Duration In Month</Label>
                  <Input type="text" className="form-control"name="DurationInMonth" value={props.committeValues.DurationInMonth} onChange={props.handleCommitteInputChange} />
                </FormGroup>
              </Col>
              <Col md={3}>
                <FormGroup>
                  <Label for="">Monthly installment</Label>
                  <Input type="number" className="form-control" name="MonthlyInstallment" value={props.committeValues.MonthlyInstallment} onChange={props.handleCommitteInputChange} />
                </FormGroup>
              </Col>
              <Col md={3}>
              <FormGroup>
               <Label for="InputDate">Start Date</Label>
              <Input type="date" className="form-control" id="InputDate" name="StartDate" value={props.committeValues.StartDate} onChange={props.handleCommitteInputChange} />
              </FormGroup>
              </Col>
              <Col md={3}>
              <FormGroup>
               <Label for="InputDate">End Date</Label>
              <Input type="date" className="form-control" id="InputDate" name="EndDate" value={props.committeValues.EndDate} onChange={props.handleCommitteInputChange} />
              </FormGroup>
              </Col>
              <Col md={3}>
                <FormGroup>
                  <Label for="">Remarks</Label>
                  <Input type="text" className="form-control" name="Remarks" value={props.committeValues.Remarks} onChange={props.handleCommitteInputChange} />
                </FormGroup>
              </Col>
            </Row>
            <Row  className="text-right">
              <Col md={12}>
                <FormGroup>
                  <Button color="primary" onClick={(e)=>AddCommitteInGrid(e)}>Add</Button>
                </FormGroup>
              </Col>
            </Row>
          </Form>
          <Row>
            <Col md={12}>
              <h2 className="h6">Committe Details</h2>
            </Col>
          </Row>
          <Row>
            <Col md={12}>
              <Table bordered striped responsive>
                <thead>
                  <tr>
                    <th>Sr #</th>
                    <th>Purpose</th>
                    <th>Committe Amount</th>
                    <th>Duration</th>
                    <th>Monthly Installment</th>
                    <th>Start Date</th>
                    <th>End Date</th>
                    <th>Remarks</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                 {
            props.committeValues.CommitteGrid &&
                            props.committeValues.CommitteGrid.map((item, key) => (
                              <tr key={key+1}>
                                <td>{key+1}</td>
                              <td>{item.Purpose}</td>
                              <td>{item.CommitteAmount}</td>
                              <td>{item.DurationInMonth}</td>
                              <td>{item.MonthlyInstallment}</td>
                              <td>{item.StartDate}</td>
                              <td>{item.EndDate}</td>
                              <td>{item.Remarks}</td>
                               <td>
                          <Button color="danger" outline size="sm" onClick={(e) => onDeleteCommitte( item.Purpose,e)}><i className="nc-icon nc-simple-remove"></i></Button>
                        </td>
                              </tr>
                            ))
                          }  
                </tbody>
              </Table>
            </Col>
          </Row>
        </CardBody>
      </Card>



    </div>
    );



}

export default LoanDetails