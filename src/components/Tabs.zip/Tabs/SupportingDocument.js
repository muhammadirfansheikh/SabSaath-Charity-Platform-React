import React, { useState, Link } from 'react'
import { useHistory } from "react-router-dom";
import {
  Card,
  CardHeader,
  CardBody,
  CardTitle,
  Table,
  Row,
  Col,
  Button,
  FormGroup,
  Form,
  Label,
  Option,
  Input,
  check,
  Badge
} from "reactstrap";
import ModalApplHistory from '../../components/modal/ModalApplHistory.js'


const SupportingDocument = (props) => {

  const [openModal, setOpenModal] = useState(false);
  const openNewmodal = () => {
    
     setOpenModal(true);
   }
   const closeNewmodal = () => {
     setOpenModal(false);
   } 
const onDeleteSupportDoc = ({ SupportDocumnetTypeId }) => {
    console.log(SupportDocumnetTypeId);
    var listsupportingDoc=props.supportingDocValues.SupportDocGrid;
    const indx = listsupportingDoc.findIndex(v => v.SupportDocumnetTypeId === SupportDocumnetTypeId);
    listsupportingDoc.splice(indx, indx >= 0 ? 1 : 0);
    props.handleSuppDocGridChange(listsupportingDoc);
  }
  
   function handleAddSupportDoc(e)
   {
     e.preventDefault();
  var alreadyexists=false;
  var SupportDocGridData=props.supportingDocValues.SupportDocGrid===undefined?[]:props.supportingDocValues.SupportDocGrid;
      if(props.supportingDocValues.SupportDocumnetTypeId==='0' || props.supportingDocValues.SelectedFiles===null || props.supportingDocValues.SupportFile==='')
      {
        alert("Must fill the fields");
      }
      else
      {
        if(SupportDocGridData.length>0)
        {
            alreadyexists=SupportDocGridData.some(el => el.SupportDocumnetTypeId === props.supportingDocValues.SupportDocumnetTypeId);
            alreadyexists && alert("Already Exists");
        }
        if(!alreadyexists)
        {
          var SupportDocumentName=props.supportingDocValues.SupportDocumnetTypeddl.filter(e=>e.SetupDetailId==props.supportingDocValues.SupportDocumnetTypeId)[0].SetupDetailName;
     
            SupportDocGridData.push({SupportDocumnetTypeId:props.supportingDocValues.SupportDocumnetTypeId
            ,DocumentType:SupportDocumentName,FileName:props.supportingDocValues.SupportFile});

            props.handleSuppDocGridChange(SupportDocGridData);
        }
      }
   }
function handleDocumentParentChange(e) {
  debugger;
  props.handleAdditionDocInputChange(e);
  var subtypeddl=props.additionDocValues.DocumnetSubTypeddl;
 var filterArray= subtypeddl.filter(el=>el.ParentId==e.target.value);

  props.setAdditionDocValues({
      ...props.additionDocValues,
      FilteredDocumentSubType: filterArray,DocumnetTypeId:e.target.value
    })
}

const onDeleteAdditionalDoc = ({ DocumnetTypeId,DocumnetSubTypeId }) => {
    console.log(DocumnetTypeId);
    var listAdditionalDoc=props.additionDocValues.AdditionalDocGrid;
    const indx = listAdditionalDoc.findIndex(v => v.DocumnetTypeId === DocumnetTypeId && v.DocumnetSubTypeId === DocumnetSubTypeId);
    listAdditionalDoc.splice(indx, indx >= 0 ? 1 : 0);
    props.handleAdditionalDocGridChange(listAdditionalDoc);
  }
  
   function handleAddAdditionalDoc(e)
   {
     debugger; 
     e.preventDefault();
  var alreadyexists=false;
  var AdditionalDocGridData=props.additionDocValues.AdditionalDocGrid===undefined?[]:props.additionDocValues.AdditionalDocGrid;
      if(props.additionDocValues.DocumnetTypeId==='0' || props.additionDocValues.DocumnetSubTypeId==='0' || props.additionDocValues.SelectedFile==='' || props.additionDocValues.FileName==='')
      {
        alert("Must fill the fields");
      }
      else
      {
        if(AdditionalDocGridData.length>0)
        {
            alreadyexists=AdditionalDocGridData.some(el => el.DocumnetTypeId === props.additionDocValues.DocumnetTypeId && el.DocumnetSubTypeId === props.additionDocValues.DocumnetSubTypeId);
            alreadyexists && alert("Already Exists");
        }
        if(!alreadyexists)
        {
          var DocumentParentType=props.additionDocValues.DocumnetTypeddl.filter(e=>e.SetupDetailId==props.additionDocValues.DocumnetTypeId)[0].SetupDetailName;
          var DocumentSubType=props.additionDocValues.DocumnetSubTypeddl.filter(e=>e.SetupDetailId==props.additionDocValues.DocumnetSubTypeId)[0].SetupDetailName;
     
            AdditionalDocGridData.push({DocumnetTypeId:props.additionDocValues.DocumnetTypeId
            ,DocumnetSubTypeId:props.additionDocValues.DocumnetSubTypeId
            ,DocumentParentType:DocumentParentType,DocumentSubType:DocumentSubType,FileName:props.additionDocValues.FileName});

            props.handleAdditionalDocGridChange(AdditionalDocGridData);
        }
      }
   }
  return (
    <div>
    <Row>
    <Col md={12} className="text-right">
      <Button color="secondary" className="btn-sm" type="submit" onClick={() => openNewmodal({ UserId: 0 })}>History</Button>
    </Col>
    </Row>
      <Card className="mb-3">
        <CardHeader>
          <h6 className="font-weight-bold mb-0">Supporting Document</h6>
          
        </CardHeader>
        <CardBody>
          <Form>
            <Row form>
            <Col md={3}>
            <FormGroup>
              <Label for="">Document Type</Label>
              <Input type="select" className="form-control" name="SupportDocumnetTypeId" value={props.supportingDocValues.SupportDocumnetTypeId} onChange={props.handleSupportDocInputChange}>
            <option key={0} value={0} >Select</option>
            {
              props.supportingDocValues.SupportDocumnetTypeddl &&
                            props.supportingDocValues.SupportDocumnetTypeddl.map((item, key) => (
                              <option key={item.SetupDetailId} value={item.SetupDetailId}>
                                {item.SetupDetailName}
                              </option>
                            ))
                          }  
          </Input>
            </FormGroup>
            
          </Col>
          
              <Col md={3}>
                <FormGroup>
                  <Label for="">File Name</Label>
                  <Input type="text"  className="form-control" name="SupportFile" value={props.supportingDocValues.SupportFile} onChange={props.handleSupportDocInputChange} />
                  </FormGroup>
              </Col>
              <Col md={3}>
                <FormGroup>
                  <Label for="">Upload Attachment</Label>
                  <Input type="file" multiple={false} className="form-control" name="SelectedFiles"  onChange={props.handleSupportDocInputChange}  />
                </FormGroup>
              </Col>
            </Row>
            <Row form className="text-right">
              <Col md={12}>
                <FormGroup>
                  <Button color="primary" onClick={(e)=>handleAddSupportDoc(e)}>Add</Button>
                </FormGroup>
              </Col>
            </Row>
          </Form>

          <Row>
            <Col md={12}>
              <h2 className="h6">Details</h2>
            </Col>
          </Row>
          <Row>
            <Col md={12}>
              <Table bordered striped responsive>
                <thead>
                  <tr>
                    <th>Sr #</th>
                    <th>File Name</th>
                    <th>Document Type</th>
                    <th>Download</th>
                    <th>View</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  {
            props.supportingDocValues.SupportDocGrid &&
                            props.supportingDocValues.SupportDocGrid.map((item, key) => (
                              <tr key={key}>
                              <td>{key+1}</td>
                             <td>{item.FileName}</td>
                              <td>{item.DocumentType}</td>
                               <td></td>
                               <td></td>
                               <td>
                          <Button color="danger" outline size="sm" onClick={() => onDeleteSupportDoc({ SupportDocumnetTypeId: item.SupportDocumnetTypeId })}><i className="nc-icon nc-simple-remove"></i></Button>
                        </td>
                              </tr>
                            ))
                  }
                </tbody>
              </Table>
            </Col>
          </Row>

        </CardBody>
      </Card>
      {/* <Row className="text-right">
        <Col md={12}>
          <Button color="primary">Save</Button>
        </Col>
      </Row> */}

      <Card className="mb-3">
        <CardHeader>
          <h6 className="font-weight-bold mb-0">Additional Document</h6>
        </CardHeader>
        <CardBody>
          <Form>
            <Row form>
            <Col md={3}>
            <FormGroup>
              <Label for="">Assistance Category</Label>
               <Input type="select" className="form-control" name="DocumnetTypeId" value={props.additionDocValues.DocumnetTypeId} onChange={(e)=>handleDocumentParentChange(e)}>
            <option key={0} value={0} >Select</option>
            {
              props.additionDocValues.DocumnetTypeddl &&
                            props.additionDocValues.DocumnetTypeddl.map((item, key) => (
                              <option key={item.SetupDetailId} value={item.SetupDetailId}>
                                {item.SetupDetailName}
                              </option>
                            ))
            } 
          </Input>
            </FormGroup>
          </Col>
          <Col md={3}>
            <FormGroup>
              <Label for="">Document Type</Label>
             <Input type="select" className="form-control" name="DocumnetSubTypeId" value={props.additionDocValues.DocumnetSubTypeId} onChange={props.handleAdditionDocInputChange}>
            <option key={0} value={0} >Select</option>
            {
              props.additionDocValues.FilteredDocumentSubType &&
                            props.additionDocValues.FilteredDocumentSubType.map((item, key) => (
                              <option key={item.SetupDetailId} value={item.SetupDetailId}>
                                {item.SetupDetailName}
                              </option>
                            ))
            } 
          </Input>
            </FormGroup>
          </Col>
              <Col md={3}>
                <FormGroup>
                  <Label for="">File Name</Label>
                  <Input type="text" className="form-control" Name="FileName" onChange={props.handleAdditionDocInputChange} />
                </FormGroup>
              </Col>
              <Col md={3}>
                <FormGroup>
                  <Label for="">Upload Attachment</Label>
                  <Input type="file" multiple={false} className="form-control" name="SelectedFile"  onChange={props.handleAdditionDocInputChange}  />
               </FormGroup>
              </Col>
            </Row>
            <Row form className="text-right">
              <Col md={12}>
                <FormGroup>
                  <Button color="primary" onClick={(e)=>handleAddAdditionalDoc(e)}>Upload</Button>
                </FormGroup>
              </Col>
            </Row>
          </Form>

          <Row>
            <Col md={12}>
              <h2 className="h6">Documents List</h2>
            </Col>
          </Row>
          <Row>
            <Col md={12}>
              <Table bordered striped responsive>
                <thead>
                  <tr>
                    <th>Sr #</th>
                    <th>File Name</th>
                    <th>Document Category</th>
                    <th>Document Type</th>
                    <th>Download</th>
                    <th>View</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                 {
            props.additionDocValues.AdditionalDocGrid &&
                            props.additionDocValues.AdditionalDocGrid.map((item, key) => (
                              <tr key={key}>
                               <td>{key+1}</td>
                             <td>{item.FileName}</td>
                              <td>{item.DocumentParentType}</td>
                              <td>{item.DocumentSubType}</td>
                               <td></td>
                               <td></td>
                               <td>
                          <Button color="danger" outline size="sm" onClick={() => onDeleteAdditionalDoc({ DocumnetTypeId: item.DocumnetTypeId,DocumnetSubTypeId:item.DocumnetSubTypeId })}><i className="nc-icon nc-simple-remove"></i></Button>
                        </td>
                              </tr>
                            ))
                  }
                </tbody>
              </Table>
            </Col>
          </Row>

        </CardBody>
      </Card>

      {
      openModal &&
      <ModalApplHistory {...props}
        HeaderText="Applicant History"
        Ismodalshow={openModal}
        closeNewmodal={closeNewmodal}
      />

    }
    </div>
  );



}

export default SupportingDocument