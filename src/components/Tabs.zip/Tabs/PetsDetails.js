import React, { useState, Link } from 'react'
import { useHistory } from "react-router-dom";
import {
  Card,
  CardHeader,
  CardBody,
  CardTitle,
  Table,
  Row,
  Col,
  Button,
  FormGroup,
  Form,
  Label,
  Option,
  Input,
  check,
  Badge
} from "reactstrap";
import {GetSetupDetail_Name} from '../../utils/Common.js'
const PetsDetails = (props) => {

  const AddPetsInGrid=(e)=>{
  e.preventDefault();
  debugger;
  var alreadyexists=false;
  var PetsGridData=props.petsValues.PetsGridList===undefined?[]:props.petsValues.PetsGridList;
      if(props.petsValues.petId==='0' || props.petsValues.Quantity<=0 || props.petsValues.ExpenseAmount<=0)
      {
        alert("Must fill the fields");
      }
      else
      {
        if(PetsGridData.length>0)
        {
            alreadyexists=PetsGridData.some(el => el.petId === props.petsValues.petId);
            alreadyexists && alert("Already Exists");
        }
        if(!alreadyexists)
        {
            PetsGridData.push({PetId:props.petsValues.petId
            ,PetName:GetSetupDetail_Name(props.petsValues.petId,props.petsValues.petsddlList)
            ,Quantity:props.petsValues.Quantity
              ,ExpenseAmount:props.petsValues.ExpenseAmount});
            props.handlePetsGridChange(PetsGridData);
            
           
        }
      }
};
function GetSetupDetail_Name(SetupDetailId,SetupDetailList) {
  var filterdata="";
  if(SetupDetailId>0 && SetupDetailId!=undefined && SetupDetailId!=null)
  {
   filterdata= SetupDetailList.filter(p => p.SetupDetailId ===parseInt(SetupDetailId))[0].SetupDetailName;
  console.log("filterdata",filterdata);
  return filterdata;
  };
}
const onDelete = ({ petId }) => {
    console.log(petId);
    var listPets=props.petsValues.PetsGridList;
    const indx = listPets.findIndex(v => v.petId === petId);
listPets.splice(indx, indx >= 0 ? 1 : 0);
props.handlePetsGridChange(listPets);
  };
  return (
    <div>
      <Card className="mb-3">
        <CardHeader>
          <h6 className="font-weight-bold mb-0">Pets Details</h6>
        </CardHeader>
        <CardBody>
          <Form>
           
            <Row form>
            <Col md={4}>
                <FormGroup>
                  <Label for="InputState">Pets</Label>
                  <Input type="select" className="form-control" name="petId" value={props.petsValues.petId} onChange={props.handlePetsInputChange}>
            <option key={0} value={0} >Select</option>
            {
              props.petsValues.petsddlList &&
                            props.petsValues.petsddlList.map((item, key) => (
                              <option key={item.SetupDetailId} value={item.SetupDetailId}>
                                {item.SetupDetailName}
                              </option>
                            ))
                          }  
          </Input>
                </FormGroup>
              </Col>
              <Col md={4}>
                <FormGroup>
                  <Label for="">Quantity</Label>
                  <Input type="text" className="form-control" name="Quantity" value={props.petsValues.Quantity} onChange={props.handlePetsInputChange} />
                </FormGroup>
              </Col>
              <Col md={4}>
                <FormGroup>
                  <Label for="">Expense</Label>
                  <Input type="text" className="form-control" name="ExpenseAmount" value={props.petsValues.ExpenseAmount} onChange={props.handlePetsInputChange} />
                </FormGroup>
              </Col>
            </Row>

            <Row  className="text-right">
               <Col md={12}>
                <FormGroup>
                  <Button color="primary" onClick={AddPetsInGrid}>Add</Button>
                </FormGroup>
              </Col>
              </Row>
          </Form>

          <Row>
          <Col md={12}>
            <h2 className="h6">Pets Details</h2>
          </Col>
        </Row>
        <Row>
          <Col md={12}>
            <Table bordered striped responsive>
              <thead>
                <tr>
                  <th>Sr #</th>
                  <th>Pet</th>
                  <th>Quantity</th>
                  <th>Expense</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                  {
            props.petsValues.PetsGridList &&
                            props.petsValues.PetsGridList.map((item, key) => (
                              <tr key={key}>
                               <td>{key+1}</td>
                             <td>{item.PetName}</td>
                              <td>{item.Quantity}</td>
                              <td>{item.ExpenseAmount}</td>
                               <td>
                          <Button color="danger" outline size="sm" onClick={() => onDelete({ petId: item.petId })} ><i className="nc-icon nc-simple-remove"></i></Button>
                        </td>
                              </tr>
                            ))
                            //onClick={() => onDelete({ PetId: item.PetId })}
                          } 
              </tbody>
            </Table>
          </Col>
        </Row>

        </CardBody>
      </Card>
      
    </div>
  );



}

export default PetsDetails