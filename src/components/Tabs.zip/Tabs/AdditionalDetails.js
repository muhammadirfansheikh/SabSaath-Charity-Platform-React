import React, { useState, Link } from "react";
import { useHistory } from "react-router-dom";
import {
  Card,
  CardHeader,
  CardBody,
  CardTitle,
  Table,
  Row,
  Col,
  Button,
  FormGroup,
  Form,
  Label,
  Option,
  Input,
  check,
  Badge,
} from "reactstrap";

const AdditionalDetails = (props) => {
  return (
    <div>
      <Card className="mb-3">
        <CardHeader>
          <h6 className="font-weight-bold mb-0">Guardian Details</h6>
        </CardHeader>
        <CardBody>
          <Form>
            <Row form>
            <Col md={3}>
                <FormGroup>
                  <Label for="">Guardian CNIC</Label>
                  <Input type="number" className="form-control" name="GuardianCnic" value={props.generalAdditionalDetailValues.GuardianCnic} onChange={props.handleAdditionalInputChange} />
                </FormGroup>
              </Col>
              <Col md={3}>
                <FormGroup>
                  <Label for="">Guardian Name</Label>
                  <Input type="text" className="form-control" name="GuardianName" value={props.generalAdditionalDetailValues.GuardianName} onChange={props.handleAdditionalInputChange} />
                </FormGroup>
              </Col>
              
              <Col md={3}>
                <FormGroup>
                  <Label for="">Occupation</Label>
                  <Input type="select" className="form-control" name="OccupationId" value={props.generalAdditionalDetailValues.OccupationId} onChange={props.handleAdditionalInputChange}>
                  <option key={0} value={0} >Select</option>
            {
              props.generalAdditionalDetailValues.Occupationddl &&
                            props.generalAdditionalDetailValues.Occupationddl.map((item, key) => (
                              <option key={item.SetupDetailId} value={item.SetupDetailId}>
                                {item.SetupDetailName}
                              </option>
                            ))
                          }  
          </Input>
                </FormGroup>
              </Col>
              
            </Row>
          </Form>
        </CardBody>
      </Card>
      <Card className="mb-3">
        <CardHeader>
          <h6 className="font-weight-bold mb-0">Referrer Details</h6>
        </CardHeader>
        <CardBody>
          <Form>
            <Row form>
            <Col md={3}>
                <FormGroup>
                  <Label for="InputState">Company</Label>
                  <Input type="select" className="form-control" name="CompanyId" value={props.generalAdditionalDetailValues.CompanyId} onChange={props.handleAdditionalInputChange} >
                  <option key={0} value={0} >Select</option>
            {
              props.generalAdditionalDetailValues.Companyddl &&
                            props.generalAdditionalDetailValues.Companyddl.map((item, key) => (
                              <option key={item.CompanyId} value={item.CompanyId}>
                                {item.Company}
                              </option>
                            ))
                          }  
                  </Input>
                </FormGroup>
              </Col>
              <Col md={3}>
                <FormGroup>
                  <Label for="InputState">Referrer</Label>
                  <Input type="select" className="form-control" name="ReferrerId" value={props.generalAdditionalDetailValues.ReferrerId} onChange={props.handleAdditionalInputChange}>
                   <option key={0} value={0} >Select</option>
            {
              props.generalAdditionalDetailValues.Referrerddl &&
                            props.generalAdditionalDetailValues.Referrerddl.map((item, key) => (
                              <option key={item.SetupDetailId} value={item.SetupDetailId}>
                                {item.SetupDetailName}
                              </option>
                            ))
                          }  
                  </Input>
                </FormGroup>
              </Col>
              <Col md={3}>
                <FormGroup>
                  <Label for="InputState">Beneficiary of</Label>
                  <Input type="select" className="form-control" name="BeneficiaryId" value={props.generalAdditionalDetailValues.BeneficiaryId} onChange={props.handleAdditionalInputChange}>
                   <option key={0} value={0} >Select</option>
            {
              props.generalAdditionalDetailValues.Beneficiaryddl &&
                            props.generalAdditionalDetailValues.Beneficiaryddl.map((item, key) => (
                              <option key={item.BeneficiaryId} value={item.BeneficiaryId}>
                                {item.Beneficiary}
                              </option>
                            ))
                          }  
                  </Input>
                </FormGroup>
              </Col>
              <Col md={3}>
              <FormGroup>
              <Label for="InputState">Assistance Detail</Label>
              <Input type="select" className="form-control" name="AssistanceDetailId" value={props.generalAdditionalDetailValues.AssistanceDetailId} onChange={props.handleAdditionalInputChange}>
               <option key={0} value={0} >Select</option>
            {
              props.generalAdditionalDetailValues.AssistanceDetailddl &&
                            props.generalAdditionalDetailValues.AssistanceDetailddl.map((item, key) => (
                              <option key={item.CategoryId} value={item.CategoryId}>
                                {item.Category}
                              </option>
                            ))
                          }  
              </Input>
            </FormGroup>
              </Col>
               </Row>
               <Row form>
             
              <Col md={3}>
                <FormGroup>
                  <div className="form-check-inline mt-3 pt-3">
                    <Label className="form-check-Label">
                      <Input
                        type="checkbox"
                        className="form-check-Input"
                        value=""
                      />{" "}
                      Any Relative working
                    </Label>
                  </div>
                </FormGroup>
              </Col>
              <Col md={3}>
                <FormGroup>
                  <Label for="InputState">Organization</Label>
                  <Input type="select" className="form-control" name="OrganizationId" value={props.generalAdditionalDetailValues.OrganizationId} onChange={props.handleAdditionalInputChange}>
                 <option key={0} value={0} >Select</option>
            {
              props.generalAdditionalDetailValues.Organizationddl &&
                            props.generalAdditionalDetailValues.Organizationddl.map((item, key) => (
                              <option key={item.CompanyId} value={item.CompanyId}>
                                {item.Company}
                              </option>
                            ))
                          }  
                  </Input>
                </FormGroup>
              </Col>
              <Col md={3}>
              <FormGroup>
                  <Label for="InputState">Relative Details</Label>
                  <Input type="text" className="form-control" name="RelativeDetail" value={props.generalAdditionalDetailValues.RelativeDetail} onChange={props.handleAdditionalInputChange} />
                </FormGroup>
              </Col>
              <Col md={6}>
              <FormGroup>
                <Label for="">Remarks</Label>
                <Input type="text" className="form-control" name="Remarks" value={props.generalAdditionalDetailValues.Remarks} onChange={props.handleAdditionalInputChange} />
              </FormGroup>
              </Col>
            
            </Row>
          </Form>
        </CardBody>
      </Card>
    </div>
  );
};

export default AdditionalDetails;
